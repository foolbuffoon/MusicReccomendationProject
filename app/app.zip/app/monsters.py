##By Nikolas Kath


class Monster:
    set_damage = 0
    set_health = 0
    set_attack_interval = 0

    def __init__(self):
        self.set_damage = 0
        self.set_health = 0
        self.set_attack_interval = 0
